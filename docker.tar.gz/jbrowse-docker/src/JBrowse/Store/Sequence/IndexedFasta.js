// renamed
define( [ 'JBrowse/Store/SeqFeature/IndexedFasta' ], function(s) { return s; } );
