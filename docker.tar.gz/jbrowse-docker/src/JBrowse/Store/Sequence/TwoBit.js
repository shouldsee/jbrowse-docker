// renamed
define( [ 'JBrowse/Store/SeqFeature/TwoBit' ], function(s) { return s; } );
