define( ['JBrowse/Store/SeqFeature/BigWig'], function( bw ){
  return bw;
});
