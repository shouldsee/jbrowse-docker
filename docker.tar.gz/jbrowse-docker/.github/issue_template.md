# Creating an issue

If you are creating a new issue please report

- JBrowse version
- Web browser being used
- Operating system if relevant
- If it is setup related, setup.log


Also consider submitting questions via email to gmod-ajax@lists.sourceforge.net as GitHub issues are primarily used for bugs and feature requests
