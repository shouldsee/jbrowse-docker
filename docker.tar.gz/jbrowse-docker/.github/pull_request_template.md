# Submitting a pull request

Please base your pull request based on the "dev" branch of JBrowse

The default branch is "master" but this contains the last stable release, and new pull requests should be based off of "dev"

Then set the base branch to "dev" on GitHub also


